## Python for Exploratory Computing Webpage

Please visit the webpage of this project <a href="http://mbakker7.github.io/exploratory_computing_with_python/">here</a>.